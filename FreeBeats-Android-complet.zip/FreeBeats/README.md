# FreeBeats

Application Android de lecteur musical indépendant. Elle permet de rechercher des enregistrements proposés par Internet Archive et de lire des fichiers audio choisis sur l'appareil.

La disponibilité et les droits de chaque enregistrement dépendent de sa fiche et de sa licence sur Internet Archive.
